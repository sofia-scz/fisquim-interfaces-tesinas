# LaTeX2HTML 2008 (1.71)
# Associate internals original text with physical files.


$key = q/rigid_and_0K/;
$ref_files{$key} = "$dir".q|node13.html|; 
$noresave{$key} = "$nosave";

$key = q/constant_Ts/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:u2det/;
$ref_files{$key} = "$dir".q|node16.html|; 
$noresave{$key} = "$nosave";

$key = q/getting_the_code/;
$ref_files{$key} = "$dir".q|node7.html|; 
$noresave{$key} = "$nosave";

1;

