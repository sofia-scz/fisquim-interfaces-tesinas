# LaTeX2HTML 2008 (1.71)
# Associate images original text with physical files.


$key = q/##;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img13.png"
 ALT="$\char93 \char93 $">|; 

$key = q/i;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="11" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img18.png"
 ALT="$i$">|; 

$key = q/C_6^{ij};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="31" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img15.png"
 ALT="$C_6^{ij}$">|; 

$key = q/_4;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="$_4$">|; 

$key = q/rightarrow;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="24" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="$\rightarrow$">|; 

$key = q/leftarrow;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="24" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="$\leftarrow$">|; 

$key = q/j;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img19.png"
 ALT="$j$">|; 

$key = q/_{max};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="32" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="$_{max}$">|; 

$key = q/^2;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="22" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img21.png"
 ALT="$^2$">|; 

$key = q/{displaymath}E_{Tot}=E_{PBE}+E_{dis}=E_{PBE}-frac{1}{2}sum_{inej}frac{C_6^{ij}}{frac{0.75}{1+exp[-20(frac{r_{ij}}{R_0^{ij}}-1)]}{displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="509" HEIGHT="63" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="\begin{displaymath}
E_{Tot}=E_{PBE}+E_{dis}=E_{PBE} - \frac{1}{2} \sum_{i\ne j} ...
...} \frac{0.75}{1 + exp[-20 ( \frac{r_{ij} }{ R_0^{ij}} -1 ) ] }
\end{displaymath}">|; 

$key = q/ij;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img14.png"
 ALT="$ij$">|; 

$key = q/sim;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img20.png"
 ALT="$\sim$">|; 

$key = q/<u^2>;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="63" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img22.png"
 ALT="$&lt; u^2 &gt;$">|; 

$key = q/C_6^{ij}=sqrt{C_6^{ii}C_6^{jj}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="125" HEIGHT="55" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="$C_6^{ij}= \sqrt{C_6^{ii} C_6^{jj}}$">|; 

$key = q/R_0^{ij};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="31" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img16.png"
 ALT="$R_0^{ij}$">|; 

$key = q/^6;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="22" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img17.png"
 ALT="$^6$">|; 

$key = q/R_0^{ij}=R_0^i+R_0^j;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="122" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img12.png"
 ALT="$R_0^{ij}=R_0^i+R_0^j$">|; 

$key = q/_max;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="38" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="$_max$">|; 

$key = q/_s;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="$_s$">|; 

$key = q/_{min};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="30" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="$_{min}$">|; 

1;

