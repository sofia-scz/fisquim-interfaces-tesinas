#!/bin/bash
#
### Job Name
#$ -N gsrd-ann
#
###### Add the $ symbol after # only in the desired SGE option
#
### Select a queue
##$ -q divMC
#$ -q fiquinIB
#
#  Number of cores
##$ -pe impi_16 32
#$ -pe impi_4 8
#$ -l netIB=true
#
#  Set maximum running time
#$ -l h_rt=6:00:00
#
### Write output files .oxxxx .exxxx in current directory
#$ -cwd
#
### Merge '-j y' (do not merge '-j n') stderr into stdout stream:
#$ -j y
#
#  SGE environment variables
#$ -V
#

# -------- SECTION print some infos to stdout ---------------------------------
echo " "
echo "START_TIME           = `date +'%y-%m-%d %H:%M:%S %s'`"
START_TIME=`date +%s`
echo "HOSTNAME             = $HOSTNAME"
echo "JOB_NAME             = $JOB_NAME"
echo "JOB_ID               = $JOB_ID"
echo "SGE_O_WORKDIR        = $SGE_O_WORKDIR"
echo "NSLOTS               = $NSLOTS"
echo "PE_HOSTFILE          = $PE_HOSTFILE"
if [ -e "$PE_HOSTFILE" ]; then
  echo "--------------------------------------------------------"
  cat $PE_HOSTFILE
  echo "--------------------------------------------------------"
fi

#-------- SECTION executing gsrd  ---------------------------------------------

echo " "
echo "Calling gsrd:"
echo " "

module load intel-compiler-2018 intel-mkl-2018 intel-mpi-2018

$MPI_BIN_DIR/mpirun -np $NSLOTS /home/mramos.ifir/bin/gsrd-aenet.x 


# -------- NO NEED TO MODIFY THIS SECTION -------------------------------------
echo "END_TIME (success)   = `date +'%y-%m-%d %H:%M:%S %s'`"
END_TIME=`date +%s`
echo "RUN_TIME (hours)     = "`echo "$START_TIME $END_TIME" | awk '{printf("%.4f",($2-$1)/60.0/60.0)}'`

exit 0

