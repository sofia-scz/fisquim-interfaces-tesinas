# Procedute to compile GSRD_v1.8.0

0) Compile AENET (with the same compiler one is going to use to compile GSRD)
Before doing this, we strongly recommend to enter into the aenet folder (e.g. $HOME/AENET/aenet-master/),
edit the file: sfsetup.f90, and comment the lines:

        write(0,*) "Warning: Invalid scaling encountered in ", &                                                                        
                             "'stp_normalize()'."
        write(0,*) "         This means at least one fingerprint ", &
                             "function for ", trim(adjustl(stp%atomtype)), &
                             " is always equal to zero!"
        write(0,*) "         Maybe an atomic species is not present ", &
                             "in the reference set?"
        write(0,*) "         type       = ", trim(adjustl(stp%sftype)), &
                             " ", trim(io_adjustl(stp%sf(isf)))
        write(0,*) "         covariance = ", stp%sfval_cov(isf)
        write(0,*) "         average    = ", stp%sfval_avg(isf)
        write(0,*) "         min, max   = ", stp%sfval_min(isf), &
                                             stp%sfval_max(isf)

Obviously, this does not change any result but avoids writting several messages
if some of the descriptors is always equal to zero. This happens for instance if one  
uses different number of descriptors for different species.

1) In the aenet folder (e.g. $HOME/AENET/aenet-master/) go to the folder: lib,
select the desired compiler in the Makefile file by seting e.g. FC= ifort -c.
Then do:
make veryclean
make

2) Move back to the aenet folder and go to the folder: src.
Then do:
make -f makefiles/Makefile.ifort_intelmpi
make -f makefiles/Makefile.ifort_intelmpi lib

3) In the GSRD folder (e.g. $HOME/GSRD_codes/GSRD_v1.8.0) edit
the makefiles (e.g. Makefile_mpiifort or Makefile_gfortran) and define
the correct path for aenet (e.g. $(HOME)/AENET/aenet-master/src/).
Then, do:
 
make -f Makefile_mpiifort clean
make -f Makefile_mpiifort

or

make -f Makefile_gfortran clean
make -f Makefile_gfortran  

4) Copy the generated gsrd.x file into the bin folder of GSRD (e.g. $HOME/GSRD_codes/GSRD_v1.8.0/bin).

